<?php
	session_start();
	include_once("conexao.php");

	$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
	$cnpj = filter_input(INPUT_POST, 'cnpj', FILTER_SANITIZE_STRING);
	$endereco = filter_input(INPUT_POST, 'endereco', FILTER_SANITIZE_STRING);
	$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);
	$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
	$msg = filter_input(INPUT_POST, 'msg', FILTER_SANITIZE_STRING);

	$result_usuario = "INSERT INTO fornecedor (nome, cnpj, endereco, telefone, email, msg) VALUES ('$nome', '$cnpj', '$endereco', '$telefone', '$email', '$msg')";
	$resultado_usuario = mysqli_query($conn, $result_usuario);

if(mysqli_insert_id($conn)){
	$_SESSION['mensagem'] = "<p style='color:green;'>Cliente fornecedor com sucesso.</p>";
	header("Location: fornecedor.php");

}else
	$_SESSION['mensagem'] = "<p style='color:red;'>Cliente nao foi fornecedor com sucesso.</p>";
	header("Location: fornecedor.php");

?>