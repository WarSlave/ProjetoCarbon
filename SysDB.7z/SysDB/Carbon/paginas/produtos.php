<?php
 session_start();
?>

<!DOCTYPE HTML>
	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->
<html lang="pt-br">
	<head>
		<title> Projeto Oficina </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css" />

		<!--[if lt IE 9]>
			<script src="bower_components/html5shiv/dist/html5shiv.js"></script>
		<![endif]-->
	</head>

	<body>
		<h1>Cadastro de Produtos</h1>
	<!-- Chamando um alerta quando a mensagem no cadastros der error ou cadastras o funcionario etc-->
<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>
<!--Formulario de Cadastro de Produtos -->

		<form name="cCliente" method="POST" action="processa-produtos.php">
			<label>Codigo do Produto:</label><br>
				<input type="number" name="codigo" id="codigo" placeholder="Digite o Codigo do Produto." required maxlength="14" /><br><br>
			<label>Descriçao do Produto:</label><br>
				<input type="text" name="descricao" id="descricao" placeholder="Digite a Descriçao do Produto." required /><br><br>

			<label>Quantidade: </label><br>
				<input type="number" name="quantidade" id="quantidade" placeholder="Digite a Quantidade de Entrada." required /><br><br>
			<label>Data Vencimento:</label><br>
				<input type="date" name="data_venc" id="data_venc"/><br><br>
			<label>Data de Entrada:</label><br>
				<input type="date" name="data_entrada" id="data_entrada"/><br><br>
			<label>Valor de Venda:</label><br>
				<input type="number" name="valor_venda" id="valor_venda" placeholder="Digite o valor de Venda." required /><br><br>
			<label>Valor  de Custo:</label><br>
				<input type="number" name="valor_custo" id="valor_custo" placeholder="Digite o valor de Custo." required /><br><br>
			<input type="submit" name="Enviar" value="Cadastrar"/>

			<a href="../index.php">Voltar</a>	

		</form>
		
	</body>
	
</html>