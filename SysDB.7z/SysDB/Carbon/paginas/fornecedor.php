<?php
 session_start();
?>

<!DOCTYPE HTML>
	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->
<html lang="pt-br">
	<head>
		<title> Projeto Oficina </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css" />

		<!--[if lt IE 9]>
			<script src="bower_components/html5shiv/dist/html5shiv.js"></script>
		<![endif]-->
	</head>

	<body>
		<h1>Cadastro de Fornecedores</h1>
	<!-- Chamando um alerta quando a mensagem no cadastros der error ou cadastras o funcionario etc-->	
<?php
	if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
	}
?>
<!--Formulario de Cadastro de Clientes -->
		<form name="fornecedores" method="POST" action="processo-fornecedor.php">
			<label>Nome da Empresa:</label><br>
				<input type="text" name="nome" id="nome" placeholder="Digite o nome da Empresa." required /><br><br>
			<label>CNPJ:</label><br>
				<input type="text" name="cnpj" id="cnpj" placeholder="Digite o CNPJ" /><br><br>
			<label>Endereço:</label><br>
				<input type="text" name="endereco" id="endereco" placeholder="Digite seu Endereço." required /><br><br>
			<label>Telefone:</label><br>
				<input type="text" name="telefone" id="telefone" placeholder="Digite seu Telefone." required /><br><br>
			<label>E-mail:</label><br>
				<input type="email" name="email" id="email" placeholder="Digite seu E-mail." required /><br><br>
			<label>Observaçao:</label><br>
				<input type="text" name="msg" id="msg" placeholder="Digite Observaçao sobre o Fornecedor."  /><br><br>

			<input type="submit" name="Enviar" value="Cadastrar"/>	
			<a href="../index.php">Voltar</a>
		</form>
	
	</body>
	
</html>