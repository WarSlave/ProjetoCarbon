

<?php
 	session_start();
 	include_once("../conectar/conexao.php");
?>
<!DOCTYPE HTML>
	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->
<html lang="pt-br">
	<head>
		<title> Projeto Oficina </title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/style.css" />

		<!--[if lt IE 9]>
			<script src="bower_components/html5shiv/dist/html5shiv.js"></script>
		<![endif]-->
	</head>

	<body>

	<h1> Relatorio de Fornecedores</h1>	
	<?php
	// <!-- Chamando um alerta quando a mensagem no cadastros der error ou cadastras o fornecedor etc-->
		if(isset($_SESSION['mensagem'])){
		echo $_SESSION['mensagem'];
		unset($_SESSION['mensagem']);
		}

//Criando paginas do relatorio.

		$pagina_atual = filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);

		$pagina = (!empty($pagina_atual)) ? $pagina_atual : 1;
//Quantidade maxima de resultado por paginas!
		$qnt_result_pg = 20;

		$inicio = ($qnt_result_pg * $pagina) - $qnt_result_pg;

	//Puxar do Banco de dados as tabelas abaixo.

		$result_fornecedor = "SELECT * FROM fornecedor LIMIT $inicio, $qnt_result_pg";
		$resultado_fornecedor = mysqli_query($conn, $result_fornecedor);
		while ($row_fornecedor = mysqli_fetch_assoc($resultado_fornecedor)) {
			echo "ID: " . $row_fornecedor['id'] . "<br>";
			echo "Nome:" . $row_fornecedor['nome'] . "<br>";
			echo "CNPJ: " . $row_fornecedor['cnpj'] . "<br>";
			echo "Endereço: " . $row_fornecedor['endereco'] . "<br>";
			echo "Telefone: " . $row_fornecedor['telefone'] . "<br>";
			echo "E-mail: " . $row_fornecedor['email'] . "<br>";
			echo "Observaçao: " . $row_fornecedor['msg'] . "<br><hr>";
		}
		//Paginacao - Somar a quantidade de Usuarios

		$result_pg = "SELECT COUNT(id) AS num_result FROM fornecedor";
		$resultado_pg = mysqli_query($conn, $result_pg);
		$row_pg = mysqli_fetch_assoc($resultado_pg);
	
		$quantidade_pg = ceil($row_pg['num_result'] / $qnt_result_pg);

		$max_link = 2;

	//Quantidade de Paginas depois da Primeiras com um for para nao mostra paginas abaixo de 0 -1 -2 
			echo "<a href='relatorio-fornecedor.php?pagina=1'>Primeira </a> ";
			for($pag_ant = $pagina - $max_link; $pag_ant <= $pagina -1 ; $pag_ant++){
				
				if($pag_ant >= 1){
					echo "<a href='relatorio-fornecedor.php?pagina=$pag_ant'>$pag_ant</a> ";	
				}
			}

			echo "$pagina";

	//Quantidade de Paginas antes do Ultimo , com um for para nao mostra quantidade acima do exitido!

			for($pag_dep = $pagina +1 ; $pag_dep <= $pagina + $max_link; $pag_dep++){

					
					if($pag_dep <= $quantidade_pg){
						echo "<a href='relatorio-fornecedor.php?pagina=$pag_dep'>$pag_dep</a> ";
				}	
			}

			echo "<a href='relatorio-fornecedor.php?pagina=$quantidade_pg'>Ultima </a> ";

	?>
<br><br><br>
	<a href="../index.php">Voltar Para o Menu.</a>
	</body>
	
</html>