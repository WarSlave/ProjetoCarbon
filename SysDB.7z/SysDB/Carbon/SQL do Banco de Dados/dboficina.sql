-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 11-Mar-2018 às 17:07
-- Versão do servidor: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dboficina`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro_cliente`
--

DROP TABLE IF EXISTS `cadastro_cliente`;
CREATE TABLE IF NOT EXISTS `cadastro_cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(220) NOT NULL,
  `cpf` varchar(220) NOT NULL,
  `endereco` varchar(220) NOT NULL,
  `telefone` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `data_nasc` date NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cadastro_cliente`
--

INSERT INTO `cadastro_cliente` (`id`, `nome`, `cpf`, `endereco`, `telefone`, `email`, `data_nasc`, `msg`) VALUES
(1, 'Alyson Antonio Costa Moreira', '02389854150', 'rua a a a a', '62992007442', 'alyson.antonio@gmail.com', '1989-06-05', 'Ferrari 2008'),
(2, 'Alyson Antonio Costa Moreira', '02389854150', 'rua a a a a', '62992007442', 'alyson.antonio@gmail.com', '1989-06-05', 'Ferrari 2008'),
(3, 'franklin', '111111111', 'rua gay', '2424242424', 'franklin@gmail.com', '1989-10-05', ''),
(4, 'franklin', '111111111', 'rua gay', '2424242424', 'franklin@gmail.com', '1989-10-05', ''),
(5, 'Alyson', '02389854150', 'alyson', 'dsadas', 'alyson_acm@hotmail.com', '1989-06-05', 'aaasds');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
CREATE TABLE IF NOT EXISTS `fornecedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(220) NOT NULL,
  `cnpj` varchar(220) NOT NULL,
  `endereco` varchar(220) NOT NULL,
  `telefone` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `fornecedor`
--

INSERT INTO `fornecedor` (`id`, `nome`, `cnpj`, `endereco`, `telefone`, `email`, `msg`) VALUES
(1, 'Alyson Antonio Costa Moreira', 'sasaa', 'rua a a a a', 'dsadas', 'alyson_acm@hotmail.com', 'Ferrari 2008');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

DROP TABLE IF EXISTS `funcionarios`;
CREATE TABLE IF NOT EXISTS `funcionarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `re` varchar(220) NOT NULL,
  `nome` varchar(220) NOT NULL,
  `funcao` varchar(220) NOT NULL,
  `salario` varchar(220) NOT NULL,
  `data_admissao` date NOT NULL,
  `endereco` varchar(220) NOT NULL,
  `telefone` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `permissao` int(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`id`, `re`, `nome`, `funcao`, `salario`, `data_admissao`, `endereco`, `telefone`, `email`, `permissao`) VALUES
(1, '', 'Alyson Antonio Costa Moreira', 'Mecanico', '1111', '0111-11-11', 'rua a a a a', '62992007442', 'alyson_acm@hotmail.com', 10),
(2, '', 'Alyson', 'Mecanico', '15000', '1989-06-05', 'alyson22', '2424242424', 'alyson_antonio_@hotmail.com', NULL),
(3, '', 'Alyson Antonio Costa Moreira', 'Mecanico', '1212321', '9188-06-05', 'alyson', '62992007442', 'alyson.antonio@gmail.com', NULL),
(4, '', 'Juliana Preta', 'Mecanico', '15455', '0011-12-12', 'dasda', '2424242424', 'alyson_acm@hotmail.com', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` int(11) NOT NULL,
  `descricao` varchar(220) NOT NULL,
  `data_vali` date NOT NULL,
  `data_entrada` date NOT NULL,
  `quantidade` decimal(10,0) NOT NULL,
  `valor_custo` float NOT NULL,
  `valor_venda` float NOT NULL,
  `fornecedor` varchar(220) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
