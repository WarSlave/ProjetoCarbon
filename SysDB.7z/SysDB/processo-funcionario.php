	<!-- Programa para trabalhar em uma oficina -->
	<!-- Criado por Alyson Antonio DATA 27/02/18 as 21:40 -->


	<!-- Incluindo no banco de dados MYSQL os formularios ... -->
<?php
	session_start();
	include_once("conexao.php");

	$nome = filter_input(INPUT_POST, 'nNome', FILTER_SANITIZE_STRING);
	$CPF = filter_input(INPUT_POST, 'nCpf', FILTER_SANITIZE_STRING);
	$RG = filter_input(INPUT_POST, 'nRg', FILTER_SANITIZE_STRING);
	$nacionalidade = filter_input(INPUT_POST, 'nNacionalidade', FILTER_SANITIZE_STRING);
	$naturalidade = filter_input(INPUT_POST, 'nNaturalidade', FILTER_SANITIZE_STRING);
	$sexo = filter_input(INPUT_POST, 'nSexo', FILTER_SANITIZE_STRING);
	$dtAdmissao = filter_input(INPUT_POST, 'nDtAdimissao', FILTER_SANITIZE_STRING);
	$telefoneCel = filter_input(INPUT_POST, 'nTelCel', FILTER_SANITIZE_STRING);
	$telefoneCasa = filter_input(INPUT_POST, 'nTelCasa', FILTER_SANITIZE_STRING);
	$email = filter_input(INPUT_POST, 'nEmail', FILTER_SANITIZE_EMAIL);
	$salario = filter_input(INPUT_POST, 'nSalario', FILTER_SANITIZE_FLOAT);

	$result_usuario = "INSERT INTO funcionarios (hierarquia, nomeFunc, CPF, RG, Nacionalidade, Naturalidade, sexo, dtAdmissao, telefoneCel, telefoneCasa, email) 
		VALUES ('5', '$nome', '$CPF', '$RG', '$nacionalidade', '$naturalidade', '$sexo', '$dtAdmissao', '$telCel', '$telCasa', '$email')";

	$resultado_usuario = mysqli_query($conn, $result_usuario);
//Quando incluir no banco de dados aparecer msg de error ou nao .
if(mysqli_insert_id($conn)){
	$_SESSION['mensagem'] = "<p style='color:green;'>Funcionário cadastrado com sucesso.</p>";
	header("Location: index.html");

}else{
	$_SESSION['mensagem'] = "<p style='color:red;'>Funcionário nao foi cadastrado com sucesso.</p>";
	header("Location: funcionarios.html");
}

?>